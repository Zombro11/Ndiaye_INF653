<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zippy Used Autos</title>
    <link rel="stylesheet" href="/zippy_used_autos_mvc/assets/styles.css">
</head>
<body>
<header>
    <h1>Zippy Used Autos</h1>
</header>
<main>
